package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import Dao.LoginDa;
import config.frontconf;
import model.stocks;

@Controller
public class updatestock {
	
	@Autowired
	frontconf frontConf;
	
	@Autowired
	LoginDa loginda;
	
	@RequestMapping(value = "/update/{name}", method = RequestMethod.GET)
	public ModelAndView fetchstocks(ModelAndView Model,HttpServletRequest request,HttpServletResponse response, 
		@ModelAttribute("stock") stocks stock,@PathVariable("name")String name) {
		
		List<stocks> stocklist = loginda.findStudentByName(name);
		Model.addObject("stocklist", stocklist);
		Model.setViewName("update");

		    return Model;
		
	}
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ModelAndView insertstock(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("stock")stocks stock) {
		
		frontConf.update(stock);
		return new ModelAndView("welcome");		
	}

}
